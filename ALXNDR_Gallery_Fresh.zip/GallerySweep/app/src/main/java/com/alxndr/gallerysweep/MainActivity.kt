package com.alxndr.gallerysweep

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs

private data class Photo(
    val id: Long, val uri: Uri, val name: String, val folder: String,
    val date: Long, val bytes: Long, val width: Int, val height: Int,
    var hash: Long? = null, var blur: Double? = null, var exact: Boolean = false,
    var similar: Boolean = false, var indexed: String = ""
)

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val photos = mutableListOf<Photo>()
    private val selected = mutableSetOf<Long>()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var grid: GridLayout
    private lateinit var deleteButton: Button
    private lateinit var moreButton: Button
    private var category = "Все"
    private var showCount = 90
    private var busy = false
    private val index by lazy { getSharedPreferences("photo_index", MODE_PRIVATE) }
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale("ru"))
    private val categories = listOf("Все", "Дубли", "Похожие", "Размытые", "Скриншоты", "Большие")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestPhotos()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun text(s: String, size: Float = 14f): TextView = TextView(this).apply {
        this.text = s; textSize = size; setTextColor(Color.rgb(30, 39, 54))
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setOnClickListener { action() }
    }
    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(18), dp(12), dp(20))
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(text("🧹 ALXNDR Галерея", 25f))
        root.addView(text("Быстрая очистка без автоматического удаления", 13f))
        search = EditText(this).apply {
            hint = "Поиск: кот, машина, чек, 2026, папка…"
            isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { showCount = 90; render() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        root.addView(search)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("🔍 Проверить галерею") { scan() }, LinearLayout.LayoutParams(0, dp(55), 1f))
        actions.addView(button("🧠 Поиск по фото") { buildContentIndex() }, LinearLayout.LayoutParams(0, dp(55), 1f))
        root.addView(actions)
        root.addView(text("Поиск по содержимому работает после индексации: объекты и текст на снимках. Всё обрабатывается на телефоне.", 12f))
        val categoryScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        categories.forEach { type ->
            categoryRow.addView(button(type) { category = type; showCount = 90; render() })
        }
        categoryScroll.addView(categoryRow)
        root.addView(categoryScroll)
        status = text("Ожидание доступа к фотографиям", 13f)
        status.setPadding(0, dp(10), 0, dp(10))
        root.addView(status)
        val selectRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        selectRow.addView(button("Выбрать видимые") {
            filtered().take(showCount).forEach { selected.add(it.id) }; render()
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        selectRow.addView(button("Снять выбор") { selected.clear(); render() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(selectRow)
        deleteButton = button("🗑 Удалить выбранные (0)") { askDelete() }
        root.addView(deleteButton)
        grid = GridLayout(this).apply { columnCount = 3; alignmentMode = GridLayout.ALIGN_BOUNDS }
        root.addView(grid)
        moreButton = button("Показать ещё") { showCount += 90; render() }
        root.addView(moreButton)
    }

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 33)
            checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
                (Build.VERSION.SDK_INT >= 34 && checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED)
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestPhotos() {
        if (hasAccess()) { scan(); return }
        val permissions = when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        requestPermissions(permissions, 123)
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 123) {
            if (hasAccess()) scan() else status.text = "Для полного сканирования откройте настройки приложения и разрешите доступ ко всем фото."
        }
    }

    private fun scan() {
        if (!hasAccess()) { requestPhotos(); return }
        if (busy) return
        busy = true
        status.text = "Читаю фотографии…"
        io.execute {
            try {
                val result = mutableListOf<Photo>()
                val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DATE_TAKEN,
                    MediaStore.Images.Media.SIZE, MediaStore.Images.Media.WIDTH, MediaStore.Images.Media.HEIGHT)
                contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                    val ix = projection.map { c.getColumnIndexOrThrow(it) }
                    while (c.moveToNext()) {
                        val id = c.getLong(ix[0]); val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                        result.add(Photo(id, uri, c.getString(ix[1]) ?: "", c.getString(ix[2]) ?: "",
                            c.getLong(ix[3]), c.getLong(ix[4]), c.getInt(ix[5]), c.getInt(ix[6]),
                            indexed = index.getString("i_$id", "") ?: ""))
                    }
                }
                val bySize = result.filter { it.bytes > 0 }.groupBy { it.bytes }.filterValues { it.size > 1 }
                var groupNumber = 0
                for (group in bySize.values) {
                    val digests = mutableMapOf<String, MutableList<Photo>>()
                    for (p in group) {
                        val hash = digest(p.uri) ?: continue
                        digests.getOrPut(hash) { mutableListOf() }.add(p)
                    }
                    digests.values.filter { it.size > 1 }.forEach { duplicateGroup ->
                        duplicateGroup.forEach { it.exact = true }
                        groupNumber++
                    }
                }
                main.post {
                    photos.clear(); photos.addAll(result); selected.clear()
                    status.text = "Фото: ${result.size} · групп точных дублей: $groupNumber · анализ похожести…"
                    render()
                }
                for ((n, p) in result.withIndex()) {
                    val bmp = thumbnail(p.uri, 128) ?: continue
                    p.hash = dHash(bmp)
                    p.blur = blurScore(bmp)
                    bmp.recycle()
                    if (n % 150 == 0) main.post { status.text = "Анализ: $n / ${result.size} фотографий" }
                }
                // Candidate matches in near-date buckets: avoid full O(n²) comparisons on huge libraries.
                val buckets = result.filter { it.hash != null }.groupBy { it.date / 120_000L }
                buckets.forEach { (bucket, entries) ->
                    val candidates = entries + (buckets[bucket - 1] ?: emptyList()) + (buckets[bucket + 1] ?: emptyList())
                    for (p in entries) for (q in candidates) {
                        if (p.id >= q.id || abs(p.date - q.date) > 180_000L) continue
                        val a = p.hash ?: continue; val b = q.hash ?: continue
                        if (java.lang.Long.bitCount(a xor b) <= 7) { p.similar = true; q.similar = true }
                    }
                }
                main.post { busy = false; render() }
            } catch (e: Exception) {
                main.post { busy = false; status.text = "Ошибка сканирования: ${e.localizedMessage}" }
            }
        }
    }
    private fun digest(uri: Uri): String? {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val stream = contentResolver.openInputStream(uri) ?: return null
            stream.use { input ->
                val buf = ByteArray(65536)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) { null }
    }

    private fun thumbnail(uri: Uri, size: Int): Bitmap? = try {
        contentResolver.loadThumbnail(uri, Size(size, size), null)
    } catch (_: Exception) {
        try {
            val source = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val s = maxOf(info.size.width, info.size.height)
                val factor = maxOf(1, s / size)
                decoder.setTargetSampleSize(factor)
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } catch (_: Exception) { null }
    }
    private fun dHash(bmp: Bitmap): Long {
        val resized = Bitmap.createScaledBitmap(bmp, 9, 8, true)
        var bits = 0L
        for (y in 0 until 8) for (x in 0 until 8) {
            fun gray(p: Int) = (Color.red(p) * 30 + Color.green(p) * 59 + Color.blue(p) * 11) / 100
            bits = (bits shl 1) or (if (gray(resized.getPixel(x, y)) > gray(resized.getPixel(x + 1, y))) 1L else 0L)
        }
        resized.recycle(); return bits
    }
    private fun blurScore(bmp: Bitmap): Double {
        val b = Bitmap.createScaledBitmap(bmp, 96, 96, true)
        val g = DoubleArray(96 * 96)
        for (y in 0 until 96) for (x in 0 until 96) {
            val p = b.getPixel(x, y); g[y * 96 + x] = Color.red(p)*.299 + Color.green(p)*.587 + Color.blue(p)*.114
        }
        var sum = 0.0; var sq = 0.0; var n = 0
        for (y in 1 until 95) for (x in 1 until 95) {
            val i = y * 96 + x
            val v = 4*g[i] - g[i-1] - g[i+1] - g[i-96] - g[i+96]
            sum += v; sq += v*v; n++
        }
        b.recycle(); return sq / n - (sum/n)*(sum/n)
    }

    private fun buildContentIndex() {
        if (busy) { Toast.makeText(this, "Подождите завершения проверки", Toast.LENGTH_SHORT).show(); return }
        if (photos.isEmpty()) { scan(); return }
        busy = true
        status.text = "Индексирую объекты и текст на фото…"
        io.execute {
            val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            var processed = 0
            try {
                for (p in photos) {
                    if (p.indexed.isNotEmpty()) continue
                    val bitmap = thumbnail(p.uri, 640) ?: continue
                    val input = InputImage.fromBitmap(bitmap, 0)
                    val terms = mutableListOf<String>()
                    val done1 = CountDownLatch(1)
                    labeler.process(input).addOnSuccessListener { labels ->
                        terms.addAll(labels.filter { it.confidence >= .55f }.map { it.text })
                    }.addOnCompleteListener { done1.countDown() }
                    done1.await(15, TimeUnit.SECONDS)
                    val done2 = CountDownLatch(1)
                    recognizer.process(input).addOnSuccessListener { r ->
                        terms.add(r.text.take(4000))
                    }.addOnCompleteListener { done2.countDown() }
                    done2.await(15, TimeUnit.SECONDS)
                    bitmap.recycle()
                    val content = terms.joinToString(" ").lowercase(Locale.ROOT).ifBlank { " " }
                    p.indexed = content
                    index.edit().putString("i_${p.id}", content).apply()
                    processed++
                    if (processed % 10 == 0) main.post { status.text = "Проиндексировано: $processed · всего ${photos.size}" }
                }
                main.post { busy = false; render(); Toast.makeText(this, "Индексация завершена", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                main.post { busy = false; status.text = "Ошибка индексации: ${e.localizedMessage}" }
            } finally { labeler.close(); recognizer.close() }
        }
    }

    private fun filtered(): List<Photo> {
        val query = search.text.toString().trim().lowercase(Locale.ROOT)
        val translated = translateTerm(query)
        return photos.filter { p ->
            val typeOk = when (category) {
                "Дубли" -> p.exact
                "Похожие" -> p.similar
                "Размытые" -> p.blur?.let { it < 65.0 } == true
                "Скриншоты" -> p.folder.contains("screenshot", true) || p.name.contains("screenshot", true)
                "Большие" -> p.bytes >= 8_000_000L
                else -> true
            }
            val date = if (p.date > 0) dateFormat.format(Date(p.date)) else ""
            typeOk && (query.isBlank() || listOf(p.name.lowercase(Locale.ROOT), p.folder.lowercase(Locale.ROOT),
                date, p.indexed).any { it.contains(query) || (translated != query && it.contains(translated)) })
        }
    }
    private fun translateTerm(q: String): String = when (q) {
        "кот", "кошка", "кошки" -> "cat"
        "собака", "пёс" -> "dog"
        "машина", "автомобиль", "авто" -> "car"
        "человек", "люди" -> "person"
        "еда", "пища" -> "food"
        "документ", "бумага" -> "document"
        "дерево" -> "tree"
        "цветок", "цветы" -> "flower"
        "экран" -> "screen"
        "телефон" -> "phone"
        "компьютер" -> "computer"
        else -> q
    }

    private fun render() {
        if (!::grid.isInitialized) return
        val matched = filtered()
        status.text = "Найдено: ${matched.size} из ${photos.size} · выбрано: ${selected.size}" +
            (if (busy) " · идёт обработка…" else "")
        deleteButton.text = "🗑 Удалить выбранные (${selected.size})"
        deleteButton.isEnabled = selected.isNotEmpty() && !busy
        grid.removeAllViews()
        val margin = dp(3)
        val tileSize = (resources.displayMetrics.widthPixels - dp(24) - 6 * margin) / 3
        matched.take(showCount).forEach { p ->
            val holder = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(if (selected.contains(p.id)) Color.rgb(190, 225, 255) else Color.WHITE)
                setPadding(margin, margin, margin, margin)
                setOnClickListener {
                    if (!selected.add(p.id)) selected.remove(p.id)
                    setBackgroundColor(if (selected.contains(p.id)) Color.rgb(190, 225, 255) else Color.WHITE)
                    deleteButton.text = "🗑 Удалить выбранные (${selected.size})"
                    deleteButton.isEnabled = selected.isNotEmpty() && !busy
                }
            }
            val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            holder.addView(image, LinearLayout.LayoutParams(tileSize - dp(8), tileSize - dp(8)))
            holder.addView(text(p.name.take(16), 10f))
            val tags = buildList {
                if (p.exact) add("дубль")
                if (p.similar) add("похоже")
                if (p.blur?.let { it < 65.0 } == true) add("размыто?")
            }.joinToString(" · ")
            holder.addView(text(tags.ifEmpty { "${p.bytes / 1024 / 1024} МБ" }, 10f))
            grid.addView(holder, GridLayout.LayoutParams().apply {
                width = tileSize; height = tileSize + dp(37)
                setMargins(margin, margin, margin, margin)
            })
            io.execute {
                val bm = thumbnail(p.uri, 240)
                if (bm != null) main.post {
                    if (image.parent != null) image.setImageBitmap(bm) else bm.recycle()
                }
            }
        }
        moreButton.visibility = if (matched.size > showCount) View.VISIBLE else View.GONE
    }

    private fun askDelete() {
        if (selected.isEmpty() || busy) return
        val ids = selected.toSet()
        android.app.AlertDialog.Builder(this)
            .setTitle("Удалить ${ids.size} фото?")
            .setMessage("Android покажет системное подтверждение. Восстановление зависит от корзины галереи. Сначала проверьте выбор!")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Продолжить") { _, _ ->
                try {
                    // IntentSender request is supported starting with Android 11 (minSdk 30).
                    val uris = photos.filter { it.id in ids }.take(500).map { it.uri }
                    val pending: PendingIntent = MediaStore.createDeleteRequest(contentResolver, uris)
                    startIntentSenderForResult(pending.intentSender, 445, null, 0, 0, 0)
                } catch (e: Exception) { Toast.makeText(this, "Не удалось запросить удаление: ${e.message}", Toast.LENGTH_LONG).show() }
            }.show()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 445) {
            if (resultCode == RESULT_OK) {
                selected.clear(); scan()
            } else Toast.makeText(this, "Удаление отменено", Toast.LENGTH_SHORT).show()
        }
    }
}
