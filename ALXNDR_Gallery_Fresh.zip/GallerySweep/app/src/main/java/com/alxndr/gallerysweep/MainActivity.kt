package com.alxndr.gallerysweep

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

private data class Photo(
    val id: Long,
    val uri: Uri,
    val name: String,
    val folder: String,
    val date: Long,
    val bytes: Long,
    val width: Int,
    val height: Int,
    val stamp: String,
    var hash: Long? = null,
    var blur: Double? = null,
    var exact: Boolean = false,
    var similar: Boolean = false,
    var indexed: String = "",
    var thumbnailLoaded: Boolean = false,
)

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private val thumbs = Executors.newFixedThreadPool(4)
    private val main = Handler(Looper.getMainLooper())
    private val photos = mutableListOf<Photo>()
    private val selected = mutableSetOf<Long>()
    private val imageViews = mutableMapOf<Long, ImageView>()
    private val loadedThumbs = mutableMapOf<Long, Bitmap>()

    private lateinit var root: LinearLayout
    private lateinit var headerTitle: TextView
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var grid: GridLayout
    private lateinit var deleteButton: Button
    private lateinit var moreButton: Button
    private lateinit var analyzeButton: Button
    private lateinit var searchButton: Button
    private lateinit var summaryPhotos: TextView
    private lateinit var summaryFree: TextView
    private lateinit var categoryRow: LinearLayout

    private val index by lazy { getSharedPreferences("photo_index", MODE_PRIVATE) }
    private val analysis by lazy { getSharedPreferences("photo_analysis", MODE_PRIVATE) }
    private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale("ru"))
    private val categories = listOf("Все", "Дубли", "Похожие", "Размытые", "Скриншоты", "Большие")
    private val categoryButtons = linkedMapOf<String, Button>()

    private var category = "Все"
    private var showCount = 90
    private var analyzing = false
    private var indexing = false
    private var lastScanMessage = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestPhotos()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun fmtSize(bytes: Long): String {
        val mb = bytes / 1024.0 / 1024.0
        return when {
            mb >= 1024 -> String.format(Locale.US, "%.1f ГБ", mb / 1024.0)
            mb >= 10 -> String.format(Locale.US, "%.0f МБ", mb)
            else -> String.format(Locale.US, "%.1f МБ", mb)
        }
    }

    private fun titleText(s: String, size: Float = 16f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun bodyText(s: String, size: Float = 13f, color: Int = Color.rgb(205, 211, 223), bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun pillButton(label: String, bg: Int, fg: Int, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(fg)
        setBackgroundColor(bg)
        setOnClickListener { action() }
        minHeight = dp(48)
        minimumHeight = dp(48)
        textSize = 14f
        setPadding(dp(14), 0, dp(14), 0)
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(10, 14, 22)) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(24))
            setBackgroundColor(Color.rgb(10, 14, 22))
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "◉"
            textSize = 32f
            setTextColor(Color.rgb(255, 214, 10))
        }
        header.addView(logo)
        val headerTexts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        headerTitle = titleText("ALXNDR Галерея", 24f, Color.WHITE, true)
        headerTexts.addView(headerTitle)
        headerTexts.addView(bodyText("Фото видно сразу • анализ в фоне", 13f, Color.rgb(173, 180, 196)))
        header.addView(headerTexts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        search = EditText(this).apply {
            hint = "Поиск: кот, машина, чек, 2026, папка..."
            isSingleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(143, 149, 164))
            setBackgroundColor(Color.rgb(22, 28, 39))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { showCount = 90; render() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        val searchLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        searchLp.topMargin = dp(12)
        root.addView(search, searchLp)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        analyzeButton = pillButton("⚡ Обновить анализ", Color.rgb(255, 214, 10), Color.BLACK) { runAnalysis(force = true) }
        searchButton = pillButton("🧠 Индексировать поиск", Color.rgb(22, 28, 39), Color.WHITE) { buildContentIndex() }
        val actionLp = LinearLayout.LayoutParams(0, dp(58), 1f)
        actionLp.topMargin = dp(12)
        actionLp.marginEnd = dp(6)
        actionRow.addView(analyzeButton, actionLp)
        val actionLp2 = LinearLayout.LayoutParams(0, dp(58), 1f)
        actionLp2.topMargin = dp(12)
        actionRow.addView(searchButton, actionLp2)
        root.addView(actionRow)
        root.addView(bodyText("Фото открываются сразу. Повторно считаются только новые или изменённые снимки.", 12f, Color.rgb(160, 168, 184)).apply {
            setPadding(0, dp(8), 0, 0)
        })

        val catScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(12), 0, 0)
        }
        categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        catScroll.addView(categoryRow)
        root.addView(catScroll)
        categories.forEach { name ->
            val btn = pillButton(name, if (name == category) Color.rgb(255, 214, 10) else Color.rgb(22, 28, 39), if (name == category) Color.BLACK else Color.WHITE) {
                category = name
                showCount = 90
                updateCategoryStyles()
                render()
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48))
            lp.marginEnd = dp(8)
            categoryRow.addView(btn, lp)
            categoryButtons[name] = btn
        }

        val summaryCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(18, 23, 33))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            gravity = Gravity.CENTER_VERTICAL
        }
        val leftSummary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        leftSummary.addView(titleText("Галерея", 16f, Color.WHITE, true))
        summaryPhotos = bodyText("0 фото", 14f, Color.rgb(214, 220, 232))
        leftSummary.addView(summaryPhotos)
        val rightSummary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        rightSummary.addView(bodyText("Можно освободить", 13f, Color.rgb(173, 180, 196)))
        summaryFree = titleText("0 МБ", 18f, Color.rgb(255, 214, 10), true)
        rightSummary.addView(summaryFree)
        val cardLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val summaryLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        summaryLp.topMargin = dp(14)
        summaryCard.addView(leftSummary, cardLp)
        summaryCard.addView(rightSummary, cardLp)
        root.addView(summaryCard, summaryLp)

        status = bodyText("Ожидание доступа к фотографиям", 13f, Color.rgb(189, 196, 209))
        status.setPadding(0, dp(10), 0, dp(6))
        root.addView(status)

        val selectRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val selectVisible = pillButton("Выбрать видимые", Color.rgb(30, 37, 49), Color.WHITE) {
            filtered().take(showCount).forEach { selected.add(it.id) }
            render()
        }
        val clearVisible = pillButton("Снять выбор", Color.rgb(30, 37, 49), Color.WHITE) {
            selected.clear()
            render()
        }
        selectRow.addView(selectVisible, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(6) })
        selectRow.addView(clearVisible, LinearLayout.LayoutParams(0, dp(54), 1f))
        root.addView(selectRow)

        deleteButton = pillButton("🗑 Удалить выбранные (0)", Color.rgb(255, 214, 10), Color.BLACK) { askDelete() }
        root.addView(deleteButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(10) })

        grid = GridLayout(this).apply {
            columnCount = 2
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        moreButton = pillButton("Показать ещё", Color.rgb(30, 37, 49), Color.WHITE) { showCount += 60; render() }
        root.addView(moreButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply { topMargin = dp(12) })
    }

    private fun updateCategoryStyles() {
        categoryButtons.forEach { (name, button) ->
            val active = name == category
            button.setBackgroundColor(if (active) Color.rgb(255, 214, 10) else Color.rgb(22, 28, 39))
            button.setTextColor(if (active) Color.BLACK else Color.WHITE)
            button.text = when (name) {
                "Дубли" -> "Дубли ${photos.count { it.exact }.takeIf { it > 0 }?.let { "($it)" } ?: ""}".trim()
                "Похожие" -> "Похожие ${photos.count { it.similar }.takeIf { it > 0 }?.let { "($it)" } ?: ""}".trim()
                "Размытые" -> "Размытые ${photos.count { it.blur?.let { b -> b < 65.0 } == true }.takeIf { it > 0 }?.let { "($it)" } ?: ""}".trim()
                else -> name
            }
        }
    }

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 33)
            checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
                (Build.VERSION.SDK_INT >= 34 && checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED)
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestPhotos() {
        if (hasAccess()) { scanQuick(); return }
        val permissions = when {
            Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
            Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
            else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        requestPermissions(permissions, 123)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 123) {
            if (hasAccess()) scanQuick() else status.text = "Разреши доступ ко всем фото, чтобы видеть всю галерею и удалять снимки."
        }
    }

    private fun scanQuick() {
        if (!hasAccess()) { requestPhotos(); return }
        status.text = "Читаю галерею..."
        io.execute {
            try {
                val result = mutableListOf<Photo>()
                val projection = arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.RELATIVE_PATH,
                    MediaStore.Images.Media.DATE_TAKEN,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.WIDTH,
                    MediaStore.Images.Media.HEIGHT
                )
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    null,
                    null,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    val ix = projection.map { c.getColumnIndexOrThrow(it) }
                    while (c.moveToNext()) {
                        val id = c.getLong(ix[0])
                        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                        val name = c.getString(ix[1]) ?: ""
                        val folder = c.getString(ix[2]) ?: ""
                        val date = c.getLong(ix[3])
                        val bytes = c.getLong(ix[4])
                        val width = c.getInt(ix[5])
                        val height = c.getInt(ix[6])
                        val stamp = "$bytes|$date|$width|$height"
                        val cached = analysis.getString("a_$id", null)
                        val p = Photo(
                            id = id,
                            uri = uri,
                            name = name,
                            folder = folder,
                            date = date,
                            bytes = bytes,
                            width = width,
                            height = height,
                            stamp = stamp,
                            indexed = index.getString("i_$id", "") ?: ""
                        )
                        if (cached != null) applyCachedAnalysis(p, cached)
                        result.add(p)
                    }
                }
                main.post {
                    photos.clear()
                    photos.addAll(result)
                    selected.clear()
                    lastScanMessage = "Галерея загружена"
                    render()
                    loadVisibleThumbs()
                    runAnalysis(force = false)
                }
            } catch (e: Exception) {
                main.post { status.text = "Ошибка чтения галереи: ${e.localizedMessage}" }
            }
        }
    }

    private fun applyCachedAnalysis(photo: Photo, raw: String) {
        val parts = raw.split("|")
        if (parts.size < 5) return
        if (parts[0] != photo.stamp) return
        photo.hash = parts[1].takeIf { it != "n" }?.toLongOrNull()
        photo.blur = parts[2].takeIf { it != "n" }?.toDoubleOrNull()
        photo.exact = parts[3] == "1"
        photo.similar = parts[4] == "1"
    }

    private fun saveAnalysis(photo: Photo) {
        analysis.edit().putString(
            "a_${photo.id}",
            listOf(
                photo.stamp,
                photo.hash?.toString() ?: "n",
                photo.blur?.toString() ?: "n",
                if (photo.exact) "1" else "0",
                if (photo.similar) "1" else "0"
            ).joinToString("|")
        ).apply()
    }

    private fun runAnalysis(force: Boolean) {
        if (analyzing || photos.isEmpty()) return
        analyzing = true
        analyzeButton.isEnabled = false
        analyzeButton.text = "⏳ Анализ..."
        io.execute {
            try {
                val needAnalyze = if (force) photos else photos.filter { it.hash == null || it.blur == null }
                if (force) {
                    photos.forEach { it.exact = false; it.similar = false }
                }
                main.post {
                    lastScanMessage = if (needAnalyze.isEmpty()) "Галерея открыта сразу" else "Показываю фото сразу, анализ и поиск идут в фоне"
                    render()
                }
                if (needAnalyze.isNotEmpty()) {
                    needAnalyze.forEachIndexed { index, p ->
                        val bmp = thumbnail(p.uri, 128) ?: return@forEachIndexed
                        p.hash = dHash(bmp)
                        p.blur = blurScore(bmp)
                        bmp.recycle()
                        saveAnalysis(p)
                        if (index % 50 == 0) main.post {
                            lastScanMessage = "Анализ в фоне: ${index + 1} / ${needAnalyze.size}"
                            renderStatusOnly()
                        }
                    }
                }

                val exactGroups = mutableMapOf<String, MutableList<Photo>>()
                photos.filter { it.bytes > 0 }.forEach { p ->
                    val key = "${p.bytes}_${p.hash ?: -1L}"
                    exactGroups.getOrPut(key) { mutableListOf() }.add(p)
                }
                photos.forEach { it.exact = false; it.similar = false }
                exactGroups.values.filter { it.size > 1 && it.first().hash != null }.forEach { group ->
                    group.forEach { it.exact = true }
                }

                val buckets = photos.filter { it.hash != null }.groupBy { it.date / 120_000L }
                buckets.forEach { (bucket, entries) ->
                    val candidates = entries + (buckets[bucket - 1] ?: emptyList()) + (buckets[bucket + 1] ?: emptyList())
                    for (p in entries) for (q in candidates) {
                        if (p.id >= q.id || abs(p.date - q.date) > 180_000L) continue
                        val a = p.hash ?: continue
                        val b = q.hash ?: continue
                        if (java.lang.Long.bitCount(a xor b) <= 7) {
                            p.similar = true
                            q.similar = true
                        }
                    }
                }
                photos.forEach { saveAnalysis(it) }
                main.post {
                    analyzing = false
                    analyzeButton.isEnabled = true
                    analyzeButton.text = "⚡ Обновить анализ"
                    lastScanMessage = "Готово: фото открываются сразу, анализ сохранён"
                    updateCategoryStyles()
                    render()
                }
            } catch (e: Exception) {
                main.post {
                    analyzing = false
                    analyzeButton.isEnabled = true
                    analyzeButton.text = "⚡ Обновить анализ"
                    status.text = "Ошибка анализа: ${e.localizedMessage}"
                }
            }
        }
    }

    private fun buildContentIndex() {
        if (indexing) return
        if (photos.isEmpty()) { scanQuick(); return }
        indexing = true
        searchButton.isEnabled = false
        searchButton.text = "⏳ Индексация..."
        lastScanMessage = "Индексирую текст и объекты для поиска"
        renderStatusOnly()
        io.execute {
            val labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            var processed = 0
            try {
                val targets = photos.filter { it.indexed.isBlank() }
                for (p in targets) {
                    val bitmap = thumbnail(p.uri, 640) ?: continue
                    val input = InputImage.fromBitmap(bitmap, 0)
                    val terms = mutableListOf<String>()
                    val done1 = CountDownLatch(1)
                    labeler.process(input).addOnSuccessListener { labels ->
                        terms.addAll(labels.filter { it.confidence >= .55f }.map { it.text })
                    }.addOnCompleteListener { done1.countDown() }
                    done1.await(15, TimeUnit.SECONDS)
                    val done2 = CountDownLatch(1)
                    recognizer.process(input).addOnSuccessListener { r ->
                        terms.add(r.text.take(4000))
                    }.addOnCompleteListener { done2.countDown() }
                    done2.await(15, TimeUnit.SECONDS)
                    bitmap.recycle()
                    val content = terms.joinToString(" ").lowercase(Locale.ROOT).ifBlank { " " }
                    p.indexed = content
                    index.edit().putString("i_${p.id}", content).apply()
                    processed++
                    if (processed % 8 == 0) main.post {
                        lastScanMessage = "Индексировано: $processed / ${targets.size}"
                        renderStatusOnly()
                    }
                }
                main.post {
                    indexing = false
                    searchButton.isEnabled = true
                    searchButton.text = "🧠 Индексировать поиск"
                    lastScanMessage = "Индексация завершена"
                    render()
                    Toast.makeText(this, "Поиск по фото готов", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                main.post {
                    indexing = false
                    searchButton.isEnabled = true
                    searchButton.text = "🧠 Индексировать поиск"
                    status.text = "Ошибка индексации: ${e.localizedMessage}"
                }
            } finally {
                labeler.close()
                recognizer.close()
            }
        }
    }

    private fun filtered(): List<Photo> {
        val query = search.text.toString().trim().lowercase(Locale.ROOT)
        val translated = translateTerm(query)
        return photos.filter { p ->
            val typeOk = when (category) {
                "Дубли" -> p.exact
                "Похожие" -> p.similar
                "Размытые" -> p.blur?.let { it < 65.0 } == true
                "Скриншоты" -> p.folder.contains("screenshot", true) || p.name.contains("screenshot", true)
                "Большие" -> p.bytes >= 8_000_000L
                else -> true
            }
            val date = if (p.date > 0) dateFormat.format(Date(p.date)) else ""
            typeOk && (
                query.isBlank() || listOf(
                    p.name.lowercase(Locale.ROOT),
                    p.folder.lowercase(Locale.ROOT),
                    date,
                    p.indexed
                ).any { it.contains(query) || (translated != query && it.contains(translated)) }
            )
        }
    }

    private fun translateTerm(q: String): String = when (q) {
        "кот", "кошка", "кошки" -> "cat"
        "собака", "пёс" -> "dog"
        "машина", "автомобиль", "авто" -> "car"
        "человек", "люди" -> "person"
        "еда", "пища" -> "food"
        "документ", "бумага", "чек" -> "receipt"
        "дерево" -> "tree"
        "цветок", "цветы" -> "flower"
        "экран", "скрин", "скриншот" -> "screen"
        "телефон" -> "phone"
        "компьютер", "пк" -> "computer"
        else -> q
    }

    private fun renderStatusOnly() {
        val matched = filtered().size
        val selectedBytes = photos.filter { it.id in selected }.sumOf { it.bytes }
        summaryPhotos.text = "${photos.size} фото • ${fmtSize(photos.sumOf { it.bytes })}"
        summaryFree.text = fmtSize(selectedBytes.takeIf { it > 0 } ?: estimateFreeSpace())
        status.text = buildString {
            append(lastScanMessage)
            append(" • найдено: $matched")
            if (analyzing) append(" • анализ в фоне")
            if (indexing) append(" • индексирую поиск")
        }
        deleteButton.text = "🗑 Удалить выбранные (${selected.size})"
        deleteButton.isEnabled = selected.isNotEmpty() && !analyzing
    }

    private fun estimateFreeSpace(): Long {
        return photos.filter { it.exact || it.similar || it.blur?.let { b -> b < 65.0 } == true }.sumOf { it.bytes } / 3
    }

    private fun render() {
        updateCategoryStyles()
        renderStatusOnly()
        val matched = filtered()
        grid.removeAllViews()
        imageViews.clear()
        val margin = dp(4)
        val tileWidth = (resources.displayMetrics.widthPixels - dp(28) - margin * 2) / 2
        matched.take(showCount).forEach { p ->
            val holder = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(if (selected.contains(p.id)) Color.rgb(32, 46, 68) else Color.rgb(18, 23, 33))
                setPadding(dp(6), dp(6), dp(6), dp(8))
                setOnClickListener {
                    if (!selected.add(p.id)) selected.remove(p.id)
                    render()
                }
            }
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.rgb(38, 44, 58))
                setImageBitmap(loadedThumbs[p.id])
            }
            imageViews[p.id] = image
            val imgLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, tileWidth)
            holder.addView(image, imgLp)
            val nameTv = bodyText(p.name.ifBlank { "Без имени" }, 12f, Color.WHITE, true)
            nameTv.setPadding(0, dp(6), 0, 0)
            holder.addView(nameTv)
            val info = buildList {
                add(fmtSize(p.bytes))
                if (p.exact) add("дубль")
                if (p.similar) add("похоже")
                if (p.blur?.let { it < 65.0 } == true) add("размыто")
            }.joinToString(" • ")
            holder.addView(bodyText(info, 11f, Color.rgb(176, 183, 197)))
            grid.addView(holder, GridLayout.LayoutParams().apply {
                width = tileWidth
                setMargins(margin, margin, margin, margin)
            })
        }
        moreButton.visibility = if (matched.size > showCount) View.VISIBLE else View.GONE
        loadVisibleThumbs()
    }

    private fun loadVisibleThumbs() {
        filtered().take(showCount).forEach { photo ->
            if (loadedThumbs.containsKey(photo.id)) {
                imageViews[photo.id]?.setImageBitmap(loadedThumbs[photo.id])
                return@forEach
            }
            thumbs.execute {
                val bm = thumbnail(photo.uri, 320)
                if (bm != null) {
                    loadedThumbs[photo.id] = bm
                    main.post {
                        imageViews[photo.id]?.setImageBitmap(bm)
                    }
                }
            }
        }
    }

    private fun thumbnail(uri: Uri, size: Int): Bitmap? = try {
        contentResolver.loadThumbnail(uri, Size(size, size), null)
    } catch (_: Exception) {
        try {
            val source = ImageDecoder.createSource(contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val s = maxOf(info.size.width, info.size.height)
                val factor = maxOf(1, s / size)
                decoder.setTargetSampleSize(factor)
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } catch (_: Exception) { null }
    }

    private fun dHash(bmp: Bitmap): Long {
        val resized = Bitmap.createScaledBitmap(bmp, 9, 8, true)
        var bits = 0L
        for (y in 0 until 8) for (x in 0 until 8) {
            fun gray(p: Int) = (Color.red(p) * 30 + Color.green(p) * 59 + Color.blue(p) * 11) / 100
            bits = (bits shl 1) or (if (gray(resized.getPixel(x, y)) > gray(resized.getPixel(x + 1, y))) 1L else 0L)
        }
        resized.recycle()
        return bits
    }

    private fun blurScore(bmp: Bitmap): Double {
        val b = Bitmap.createScaledBitmap(bmp, 96, 96, true)
        val g = DoubleArray(96 * 96)
        for (y in 0 until 96) for (x in 0 until 96) {
            val p = b.getPixel(x, y)
            g[y * 96 + x] = Color.red(p) * .299 + Color.green(p) * .587 + Color.blue(p) * .114
        }
        var sum = 0.0
        var sq = 0.0
        var n = 0
        for (y in 1 until 95) for (x in 1 until 95) {
            val i = y * 96 + x
            val v = 4 * g[i] - g[i - 1] - g[i + 1] - g[i - 96] - g[i + 96]
            sum += v
            sq += v * v
            n++
        }
        b.recycle()
        return sq / n - (sum / n) * (sum / n)
    }

    private fun askDelete() {
        if (selected.isEmpty() || analyzing) return
        val ids = selected.toSet()
        android.app.AlertDialog.Builder(this)
            .setTitle("Удалить ${ids.size} фото?")
            .setMessage("Сначала проверь выбранные фотографии. Android дополнительно попросит подтверждение.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Продолжить") { _, _ ->
                try {
                    val uris = photos.filter { it.id in ids }.take(500).map { it.uri }
                    val pending: PendingIntent = MediaStore.createDeleteRequest(contentResolver, uris)
                    startIntentSenderForResult(pending.intentSender, 445, null, 0, 0, 0)
                } catch (e: Exception) {
                    Toast.makeText(this, "Не удалось запросить удаление: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 445) {
            if (resultCode == RESULT_OK) {
                selected.clear()
                loadedThumbs.values.forEach { it.recycle() }
                loadedThumbs.clear()
                scanQuick()
            } else Toast.makeText(this, "Удаление отменено", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        thumbs.shutdownNow()
        io.shutdownNow()
        loadedThumbs.values.forEach { runCatching { it.recycle() } }
        loadedThumbs.clear()
    }
}
